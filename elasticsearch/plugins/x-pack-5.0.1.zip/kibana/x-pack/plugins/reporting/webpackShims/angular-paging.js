require('jquery');
require('angular');
require('../../../node_modules/angular-paging/dist/paging');

require('ui/modules').get('kibana', ['bw.paging']);
